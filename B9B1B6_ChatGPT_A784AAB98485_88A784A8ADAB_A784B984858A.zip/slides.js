(() => {
  const slides = Array.from(document.querySelectorAll(".slide"));
  const current = document.getElementById("current");
  const total = document.getElementById("total");
  const progress = document.getElementById("progress");
  const prev = document.getElementById("prev");
  const next = document.getElementById("next");
  let index = 0;

  total.textContent = String(slides.length);

  function showSlide(newIndex) {
    index = Math.max(0, Math.min(slides.length - 1, newIndex));
    slides.forEach((slide, i) => {
      slide.classList.toggle("active", i === index);
      slide.setAttribute("aria-hidden", i === index ? "false" : "true");
    });
    current.textContent = String(index + 1);
    progress.style.width = `${((index + 1) / slides.length) * 100}%`;
    prev.disabled = index === 0;
    next.disabled = index === slides.length - 1;
    document.title = `${index + 1}/${slides.length} — تأثير منصة ChatGPT`;
  }

  // في العرض العربي RTL: السهم الأيسر يتقدّم، والأيمن يرجع.
  document.addEventListener("keydown", (event) => {
    if (event.altKey || event.ctrlKey || event.metaKey) return;
    if (["INPUT", "TEXTAREA"].includes(document.activeElement.tagName) ||
        document.activeElement.isContentEditable) return;

    if (event.key === "ArrowLeft" || event.key === " " || event.key === "PageDown") {
      event.preventDefault();
      showSlide(index + 1);
    } else if (event.key === "ArrowRight" || event.key === "PageUp") {
      event.preventDefault();
      showSlide(index - 1);
    } else if (event.key === "Home") {
      showSlide(0);
    } else if (event.key === "End") {
      showSlide(slides.length - 1);
    }
  });

  prev.addEventListener("click", () => showSlide(index - 1));
  next.addEventListener("click", () => showSlide(index + 1));

  let touchStartX = 0;
  document.addEventListener("touchstart", e => { touchStartX = e.changedTouches[0].screenX; }, {passive:true});
  document.addEventListener("touchend", e => {
    const delta = e.changedTouches[0].screenX - touchStartX;
    if (Math.abs(delta) > 90) showSlide(delta < 0 ? index + 1 : index - 1);
  }, {passive:true});

  showSlide(0);
})();